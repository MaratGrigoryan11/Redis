<?php
interface CacheInterface{
    public function save();
    public function get();
    public function delete();
}
?>