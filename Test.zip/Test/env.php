<?php
return [
    'DB_CONNECTION' => 'redis'
];