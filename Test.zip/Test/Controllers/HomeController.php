<?php

class HomeController
{
    public function index()
    {
        include 'Views/Home/index.html';
    }
}